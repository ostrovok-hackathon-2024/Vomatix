package com.vomatix.reserva

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.vomatix.reserva.databinding.ActivityHotelViewBinding
import okhttp3.Credentials
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

class HotelView : AppCompatActivity(), RoomListAdapter.Listener {

    lateinit var binding: ActivityHotelViewBinding
    private lateinit var requestData: SearchRequest
    private lateinit var credentials: String

    private val adapter = RoomListAdapter(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHotelViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPref = getSharedPreferences("hotel", Context.MODE_PRIVATE)
        val hotelId = sharedPref.getString("id", "0")
        val rate = sharedPref.getInt("rate", 2)
        val hotelName = sharedPref.getString("hotelName", "0")

        binding.name.text = hotelName.toString()
        binding.rating.rating = rate.toFloat()
        binding.back.setOnClickListener{
            finish()
        }
        apiAuth()
        sendReguest()
//        loadHotels(hotelId!!)
        loadHotels("parallel_hotel")

    }
    private fun loadHotels(hotelId: String) {
        RetrofitInstance.api.searchHotels(credentials, requestData).enqueue(object : Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody is Map<*, *>) {
                        val data = responseBody["data"] as? Map<*, *>
                        val hotels = data?.get("hotels") as? List<Map<*, *>>

                        // Поиск отеля по его hotelId
                        val hotel = hotels?.find { it["id"] == hotelId }
                        if (hotel != null) {
                            val rates = hotel["rates"] as? List<Map<*, *>>

                            // Создаем Set для хранения уникальных комбинаций (roomName + dailyPrice)
                            val uniqueRooms = mutableSetOf<Pair<String, String>>()

                            rates?.forEach { rate ->
                                val roomName = rate["room_name"] as? String ?: "Unknown Room"
                                val dailyPrices = rate["daily_prices"] as? List<String> ?: listOf("Unknown Price")

                                // Добавляем уникальные комбинации в Set
                                dailyPrices.forEach { price ->
                                    uniqueRooms.add(roomName to price)
                                }
                            }

                            // Выводим уникальные комнаты с ценами
                            uniqueRooms.forEach { (roomName, price) ->
                                val updatedRoomData = roomData(
                                    roomName = roomName,
                                    dailyPrice = price
                                )
                                binding.s.visibility = View.GONE
                                adapter.addRoom(updatedRoomData)

                                Log.d("Error", "$hotelId  Комната: $roomName, Цена: $price")
                            }
                        } else {
                            Log.e("Error", "Отель с ID $hotelId не найден")
                        }
                    }
                } else {
                    Log.e("Error", "Ошибка: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<Any>, t: Throwable) {
                Log.e("Error", "Ошибка при запросе: ${t.message}")
            }
        })
        binding.roomRes.layoutManager = LinearLayoutManager(this@HotelView)
        binding.roomRes.adapter = adapter
    }

    data class Guest(
        // DataClass гостей
        val adults: Int,
        val children: List<Any>
    )

    data class SearchRequest(
        // DataClass API
        val checkin: String,
        val checkout: String,
        val residency: String,
        val language: String,
        val guests: List<Guest>,
        val region_id: Int,
        val currency: String,
        val hotels_limit:Int
    )

    interface ApiService {
        // Авторизация API
        @POST("api/b2b/v3/search/serp/region/")
        fun searchHotels(
            @Header("Authorization") authHeader: String,
            @Body requestBody: SearchRequest
        ): Call<Any>
    }

    object RetrofitInstance {
        // API билд
        private const val BASE_URL = "https://api.worldota.net/"

        val api: ApiService by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }

    private fun sendReguest() {
        // Отправление запроса
        RetrofitInstance.api.searchHotels(credentials, requestData).enqueue(object : Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                if (response.isSuccessful) {
                    Log.d("ResponseOstrov", "Успешный ответ: ${response.body()}")
                } else {
                    Log.e("Error", "Ошибка: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<Any>, t: Throwable) {
                Log.e("Error", "Ошибка при запросе: ${t.message}")
            }
        })
    }

    private fun apiAuth() {
        // Входные данные API
        requestData = SearchRequest(
            checkin = "2024-11-10",
            checkout = "2024-11-11",
            residency = "ru",
            language = "ru",
            guests = listOf(Guest(2, listOf())),
            region_id = 1913,
            currency = "RUB",
            hotels_limit = 2
        )

        // Базовая аутентификация
        credentials = Credentials.basic("10205", "abd18446-0971-4b0b-91f1-d8f256350b45")
    }
    data class HotelResponse(
        val hotels: List<HotelData>
    )

    data class HotelData(
        val id: String,  // строковый id отеля
        val hid: Int,    // числовой id отеля
        val name: String,
        val rates: List<Rate>
    )

    data class Rate(
        val room_name: String,
        val daily_prices: List<String>
    )

    override fun onClick(roomData: roomData) {
        val name = roomData.roomName
        val price = ((roomData.dailyPrice!!.toDouble() / 100) * 100).toInt()

        val sharedPref = getSharedPreferences("room", Context.MODE_PRIVATE).edit()
        sharedPref.putString("name", name).apply()
        sharedPref.putInt("price", price).apply()
        startActivity(Intent(this@HotelView, RoomView::class.java))
    }
}