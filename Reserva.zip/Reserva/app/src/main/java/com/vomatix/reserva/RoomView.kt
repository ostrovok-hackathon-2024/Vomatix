package com.vomatix.reserva

import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat
//import com.jjoe64.graphview.series.DataPoint
//import com.jjoe64.graphview.series.LineGraphSeries
import com.vomatix.reserva.databinding.ActivityRoomViewBinding

class RoomView : AppCompatActivity() {
    lateinit var binding: ActivityRoomViewBinding
    var price = 0
    var t1 = 0
    var t2 = 0
    var mas = 0
    var k = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoomViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.back.setOnClickListener{
            finish()
        }

        val sharedPref = getSharedPreferences("room", Context.MODE_PRIVATE)
        val name = sharedPref.getString("name", "NoName")
        val f = sharedPref.getInt("price", 0)
        price = sharedPref.getInt("price", 0) / 1000 * 1000

        binding.pr.text = "Цена: $f ₽"

        binding.name.text = name

        texts()
        mas()
        rr1()
        rr2()
        rr3()
        rr4()
        rr5()
        rr6()
        rr7()
        rr8()
        rr9()
        rr10()
        rr11()
        rr12()
    }

    private fun mas() {
        mas = (((price / 1000) * 1000) / 200 * 1.5).toInt()
        k = price * 0.000002
    }

    private fun texts() {
        t1 = ((price / 1000) * 1000) + (((price / 1000) * 1000) / 2)
        binding.t1.text = "$t1 -"
        t2 = ((price / 1000) * 1000) - (((price / 1000) * 1000) / 2)
        binding.t2.text = "$t2 -"
    }

    private fun rr1() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 11)) / mas
        setHeightInDp(binding.r1, x1)
    }

    private fun rr2() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 10)) / mas
        setHeightInDp(binding.r2, x1)
    }
    private fun rr3() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 8)) / mas
        setHeightInDp(binding.r3, x1)
    }
    private fun rr4() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 0.8)) / mas
        setHeightInDp(binding.r4, x1)
    }
    private fun rr5() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 0.6)) / mas
        setHeightInDp(binding.r5, x1)
    }
    private fun rr6() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 4)) / mas
        setHeightInDp(binding.r6, x1)
    }
    private fun rr7() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 6)) / mas
        setHeightInDp(binding.r7, x1)
    }
    private fun rr8() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 2)) / mas
        setHeightInDp(binding.r8, x1)
    }

    private fun rr9() {
        val p = price
        val x1 = ((price / 1000) * 1000) / mas
        setHeightInDp(binding.r9, x1.toDouble())
    }
    private fun rr10() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k)) / mas
        setHeightInDp(binding.r10, x1)
    }
    private fun rr11() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 8)) / mas
        setHeightInDp(binding.r11, x1)
    }
    private fun rr12() {
        val p = price
        val x1 = ((price / 1000) * 1000 + (price * k * 11)) / mas
        setHeightInDp(binding.r12, x1)
    }

    private fun setHeightInDp(view: View, heightInDp: Double) {
        // Преобразование dp в пиксели
        val heightInPixels = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            heightInDp.toFloat(),
            resources.displayMetrics
        ).toInt()

        // Установка параметров макета
        val layoutParams = view.layoutParams
        layoutParams.height = heightInPixels
        view.layoutParams = layoutParams // Применение новых параметров
    }

}