package com.vomatix.reserva

data class roomData(
    var roomName: String? = null,
    var dailyPrice: String? = null
)