package com.vomatix.reserva

data class HotelData(
    var id: String? = null,                 // Id отеля
    var nameOfHotel: String? = null,        // Название отеля
    var description: String? = null,        // Описание отеля
    var hotelPic: String? = null,           // URL изображения отеля
    var priceFrom1: Int? = null,          // Цена за ночь (например, минимальная цена)
    var priceFrom2: Int? = null,
    var rate: Int? = null,                  // Оценка/рейтинг отеля
    var meal: String? = null,               // Тип питания (например, без питания, завтрак)
    var currency: String? = null,           // Валюта, в которой указана цена (например, "RUB")
    var cancellationPolicy: String? = null, // Информация о политике отмены
    var roomType: String? = null,           // Тип номера
    var amenities: List<String>? = null     // Список удобств в номере
)