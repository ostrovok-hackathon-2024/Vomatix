package com.vomatix.reserva

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.vomatix.reserva.databinding.RoomItemBinding

class RoomListAdapter(val listener: Listener): RecyclerView.Adapter<RoomListAdapter.RoomHolder>() {
    private var roomList = mutableListOf<roomData>()
    private lateinit var mDiffResult: DiffUtil.DiffResult

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RoomHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.room_item, parent, false)
        return RoomHolder(view)
    }

    override fun getItemCount(): Int {
        return roomList.size
    }

    class RoomHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        private val binding = RoomItemBinding.bind(itemView)

        val name = itemView.findViewById<TextView>(R.id.name)!!
        val price = itemView.findViewById<TextView>(R.id.price)!!

        fun bind(roomData: roomData, listener: Listener) = with(binding) {
            itemView.setOnClickListener{
                listener.onClick(roomData)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RoomHolder, position: Int) {
        val room = roomList[position]
        holder.apply {
            holder.bind(roomList[position], listener)
            name.text = room.roomName
            price.text = "${room.dailyPrice} ₽"
        }
    }

    fun addRoom(item: roomData){
        val newList = mutableListOf<roomData>()
        newList.addAll(roomList)
        newList.add(item)
        mDiffResult = DiffUtil.calculateDiff(RoomDiffutil(roomList, newList))
        mDiffResult.dispatchUpdatesTo(this)
        roomList = newList
    }

    interface Listener{
        fun onClick(roomData: roomData)
    }
}