package com.vomatix.reserva

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.vomatix.reserva.databinding.HotelItemBinding

class HotelListAdapter(val listener: Listener): RecyclerView.Adapter<HotelListAdapter.HotelHolder>() {

    private var hotelList = mutableListOf<HotelData>()
    private lateinit var mDiffResult: DiffUtil.DiffResult

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HotelHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.hotel_item, parent, false)
        return HotelHolder(view)
    }

    override fun getItemCount(): Int {
        return hotelList.size
    }

    class HotelHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        private val binding = HotelItemBinding.bind(itemView)

        val nameOfHotel = itemView.findViewById<TextView>(R.id.name)!!
        val description = itemView.findViewById<TextView>(R.id.desc)!!
        val price = itemView.findViewById<TextView>(R.id.priceFrom)!!
        val rating = itemView.findViewById<RatingBar>(R.id.rating)!!

        fun bind(hotelData: HotelData, listener: Listener) = with(binding) {
            itemView.setOnClickListener{
                listener.onClick(hotelData)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: HotelHolder, position: Int) {
        val hotel = hotelList[position]
        holder.apply {
            holder.bind(hotelList[position], listener)
            nameOfHotel.text = hotel.nameOfHotel
            description.text = hotel.description
            price.text = "От ${hotel.priceFrom1.toString()} ₽"
            val stars = hotel.rate!!.toFloat()
            rating.rating = stars
        }
    }

    fun addHotel(item: HotelData){
        val newList = mutableListOf<HotelData>()
        newList.addAll(hotelList)
        newList.add(item)
        mDiffResult = DiffUtil.calculateDiff(DiffUtilCallback(hotelList, newList))
        mDiffResult.dispatchUpdatesTo(this)
        hotelList = newList
    }

    fun clear() {
        hotelList.clear() // Очистка списка
        notifyDataSetChanged() // Уведомление адаптера об изменениях
    }

    interface Listener{
        fun onClick(hotelData: HotelData)
    }
}