@file:Suppress("UNCHECKED_CAST")

package com.vomatix.reserva

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.vomatix.reserva.databinding.ActivityMainBinding
import okhttp3.Credentials
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.Locale
import kotlin.random.Random

@Suppress("DEPRECATION", "NAME_SHADOWING")
class MainActivity : AppCompatActivity(), HotelListAdapter.Listener {
    private var CITY = "krasnodar"
    private var reg = 1913
    /*
    Краснодар - “region_id”: 1913           krasnodar
    Нижний Новгород - “region_id”: 1361
    Минск - “region_id”: 2427
    Анталия - “region_id”: 481
    Стамбул - “region_id”: 1639
    Ереван - “region_id”: 1178*/

    private var originalHotelList = mutableListOf<HotelData>()
    private var CHECK_IN = "2024-10-03"
    private var CHECK_OUT = "2024-10-04"

    var is1 = false
    var is2 = false

    private var isCity = false
    private var isCityMay = true

    private lateinit var binding: ActivityMainBinding
    private lateinit var fadeIn: Animation
    private lateinit var fadeOut: Animation

    private lateinit var fromY1toY0: Animation
    private lateinit var fromY0toY1: Animation
    private lateinit var toTop1: Animation
    private lateinit var toBottom2: Animation
    private lateinit var fromTopToCenterFadeIn: Animation
    private lateinit var toTopFadeOut: Animation

    private lateinit var requestData: SearchRequest
    private lateinit var credentials: String

    var s = 0
    var pp1 = 1000
    var pp2 = 10000

    private val adapter = HotelListAdapter(this)

    private var page = 1

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {

        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)


        // Вызов основных функций
        mainFuncAdapter()
        initAnim()
        recInit()

        apiAuth(reg)
        filter()
        sendReguest()
        loadHotels()

        cityChoose()
        iss()
    }

    private fun iss() {
        binding.apply {
            x1.setOnClickListener {
                if (!is1){
                    priceChoose.visibility = View.VISIBLE
                    rateConstraint.visibility = View.GONE
                    is1 = true
                }else{
                    is1 = false
                    is2 = false
                    priceChoose.visibility = View.GONE
                }
            }
            x2.setOnClickListener {
                if (!is2){
                    priceChoose.visibility = View.GONE
                    rateConstraint.visibility = View.VISIBLE
                    is2 = true
                }else{
                    is1 = false
                    is2 = false
                    rateConstraint.visibility = View.GONE
                }
            }
            accept.setOnClickListener{
                pp1 = p1.text.toString().toInt()
                pp2 = p2.text.toString().toInt()
                adapter.clear()
                originalHotelList.clear()
                apiAuth(reg)
                sendReguest()
                loadHotels()
            }
        }
    }

    private fun filter() {
        binding.g2.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.r0 -> {
                    s = 0
                }
                R.id.r1 -> {
                    s = 1
                }

                R.id.r2 -> {
                    s = 2
                }

                R.id.r3 -> {
                    s = 3
                }

                R.id.r4 -> {
                    s = 4
                }

                R.id.r5 -> {
                    s = 5
                }
            }
            adapter.clear()
            originalHotelList.clear()
            apiAuth(reg)
            sendReguest()
            loadHotels()
        }
    }

    private fun setupSearch() {
        binding.searchHotelsEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Метод вызывается перед изменением текста
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Фильтруем список при каждом изменении текста
                val query = s.toString().lowercase()

                if (query.isNotEmpty()) {
                    if (binding.searchHotelsEditText.text.length == 1) {
                        binding.sVideo.visibility = View.GONE
                        binding.sVideo.startAnimation(fadeOut)
                        binding.hotelRec.visibility = View.VISIBLE
                    }

                    // Фильтрация списка отелей
                    val filteredList = originalHotelList.filter { hotel ->
                        hotel.nameOfHotel?.lowercase()?.contains(query) == true ||
                                hotel.description?.lowercase()?.contains(query) == true
                    }

                    // Обновляем адаптер с отфильтрованным списком
                    adapter.clear() // Очищаем адаптер перед добавлением
                    filteredList.forEach { adapter.addHotel(it) }
                } else {
                    // Если строка поиска пуста, восстанавливаем полный список
                    binding.sVideo.visibility = View.VISIBLE
                    binding.sVideo.startAnimation(fadeIn)
                    adapter.clear()

                }
            }

            override fun afterTextChanged(s: Editable?) {
                // Метод вызывается после изменения текста
            }
        })
    }


    private fun cityChoose() {
        binding.apply {
            if (isCityMay){
                searchCity.setOnClickListener {
                    if (!isCity) {
                        half.startAnimation(fadeIn)
                        half.visibility = View.VISIBLE
                        isCity = true
                        cityCard.startAnimation(toTop1)
                        toTop1.fillAfter = true
                        cityCard.visibility = View.VISIBLE
                    }
                }
            }
            closeCity.setOnClickListener {
                if (isCity) {
                    half.startAnimation(fadeOut)
                    half.visibility = View.GONE
                    isCity = false
                    cityCard.startAnimation(toBottom2)
                    cityCard.visibility = View.GONE
                }
            }
        }
        binding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val selectedRadioButton = findViewById<RadioButton>(checkedId)
            val selectedText = selectedRadioButton.text.toString()
            reg = selectedText.toInt()

            when(reg){
                1913 -> CITY = "krasnodar"
                1361 -> CITY = "nizhny_novgorod"
                2427 -> CITY = "minsk"
                481 -> CITY = "antalya"
                1639 -> CITY = "istanbul"
                1178 -> CITY = "yerevan"
            }
            Toast.makeText(this, "Выбрано: $reg $CITY", Toast.LENGTH_SHORT).show()

            adapter.clear()
            apiAuth(reg)
            sendReguest()
            loadHotels()
        }
    }

    private fun loadHotels() {
        // Выполняем первый запрос к API для поиска отелей
        RetrofitInstance.api.searchHotels(credentials, requestData).enqueue(object : Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                if (response.isSuccessful) {
                    val jsonResponse = response.body() as? Map<String, Any>
                    val hotels = jsonResponse?.get("data") as? Map<String, Any>
                    val hotelList = hotels?.get("hotels") as? List<Map<String, Any>>

                    // Список данных для передачи в третий запрос
                    val collectedHotelData = mutableListOf<HotelData>()

                    var nameCheck = false

                    hotelList?.forEach { hotelMap ->
                        val hotelName = hotelMap["id"] as? String ?: "Неизвестно"
                        val formattedName = formatHotelId(hotelName)

                        // Извлекаем необходимые данные из ответа
                        val rates = hotelMap["rates"] as? List<Map<String, Any>>
                        val priceFrom = rates?.get(0)?.get("daily_prices")?.let {
                            (it as? List<String>)?.firstOrNull()
                        } ?: "Цена не указана"

                        val quality =
                            (hotelMap["rg_ext"] as? Map<String, Any>)?.get("quality") as? Int ?: 0
                        val meal = rates?.get(0)?.get("meal") as? String ?: "Не указано"

                        val paymentOptions =
                            rates?.get(0)?.get("payment_options") as? Map<String, Any>
                        val paymentTypes =
                            paymentOptions?.get("payment_types") as? List<Map<String, Any>>
                        val currency =
                            paymentTypes?.get(0)?.get("currency_code") as? String ?: "RUB"

                        val cancellationPenalties =
                            paymentTypes?.get(0)?.get("cancellation_penalties") as? Map<String, Any>
                        val policies =
                            cancellationPenalties?.get("policies") as? List<Map<String, Any>>
                        val cancellationPolicy =
                            policies?.get(0)?.get("end_at") as? String ?: "Без политики отмены"

                        nameCheck = rates?.get(0)?.get("room_name") != null
                        if(nameCheck){
                            // Добавляем данные в список для третьего запроса
                            collectedHotelData.add(
                                HotelData(
                                    id = hotelName,
                                    nameOfHotel = "", // Здесь будет подстановка из третьего запроса
                                    description = rates?.get(0)?.get("room_name") as? String
                                        ?: "Описание отсутствует",
                                    hotelPic = "https://site.com", // Используй реальное поле с изображением, если есть
                                    priceFrom1 = priceFrom.toDoubleOrNull()?.toInt()?.div(100)
                                        ?.times(100),
                                    priceFrom2 = 0, // Данные из третьего запроса
                                    rate = 0, // Данные из третьего запроса
                                    meal = meal,
                                    currency = currency,
                                    cancellationPolicy = cancellationPolicy,
                                    roomType = rates?.get(0)?.get("room_name") as? String
                                        ?: "Тип комнаты не указан",
                                    amenities = hotelMap["amenities_data"] as? List<String>
                                        ?: emptyList()
                                )
                            )
                        }
                        else{
                            Log.d("HotelInfo", "Не получилось получить номера!")
                        }

                    }

                    // Выполняем запрос к HotelLook API по имени отеля
                    collectedHotelData.forEach { hotelData ->
                        HotelLookRetrofitInstance.api.getHotelByName(formatHotelId(hotelData.id.toString()))
                            .enqueue(object : Callback<HotelLookResponse> {
                                override fun onResponse(
                                    call: Call<HotelLookResponse>,
                                    hotelResponse: Response<HotelLookResponse>
                                ) {
                                    if (hotelResponse.isSuccessful) {
                                        val hotels = hotelResponse.body()?.results?.hotels
                                        if (!hotels.isNullOrEmpty()) {
                                            val randomHotelList =
                                                hotels.sortedBy { Random.nextDouble() }
                                            // Выполняем третий запрос к API HotelLook для получения информации по локации
                                            HotelLookRetrofitInstance2.api.getHotelByLocation(
                                                CITY,
                                                hotelData.currency.toString(),
                                                CHECK_IN,
                                                CHECK_OUT,
                                                20
                                            ).enqueue(object :
                                                Callback<List<HotelLookHotelResponse2>> {
                                                override fun onResponse(
                                                    call: Call<List<HotelLookHotelResponse2>>,
                                                    response: Response<List<HotelLookHotelResponse2>>
                                                ) {
                                                    if (response.isSuccessful && nameCheck) {
                                                        val hotelResponses =
                                                            response.body() // Получаем список всех отелей
                                                        hotelResponses?.let { hotels ->
                                                            // Перемешиваем список отелей
                                                            val randomHotelList = hotels.shuffled()

                                                            // Обновляем данные для каждого отеля в списке
                                                            for (i in randomHotelList.indices) {
                                                                val hotel = randomHotelList[i]
                                                                val updatedHotelData =
                                                                    hotelData.copy(
                                                                        nameOfHotel = hotel.hotelName, // Получаем имя отеля из ответа
                                                                        priceFrom2 = hotel.priceFrom.toInt(), // Получаем цену отеля из ответа
                                                                        rate = hotel.stars // Получаем рейтинг отеля из ответа
                                                                    )

                                                                // Добавляем обновленные данные в адаптер
                                                                if (s == 0){
                                                                    if (pp1 <= hotelData.priceFrom1!!.toInt() && hotelData.priceFrom1!!.toInt() <= pp2){
                                                                        originalHotelList.add(updatedHotelData)
                                                                        adapter.addHotel(updatedHotelData)
                                                                    }
                                                                }
                                                                else if (hotel.stars == s){
                                                                    if (pp1 <= hotelData.priceFrom1!!.toInt() && hotelData.priceFrom1!!.toInt() <= pp2){
                                                                        originalHotelList.add(updatedHotelData)
                                                                        adapter.addHotel(updatedHotelData)
                                                                    }
                                                                }
                                                                Log.d(
                                                                    "HotelError",
                                                                    "Ошибка1: ${response.code()}"
                                                                )
                                                            }
                                                        }
                                                    } else {
                                                        Log.e(
                                                            "HotelError",
                                                            "Ошибка2: ${response.code()}"
                                                        )
                                                    }
                                                }

                                                override fun onFailure(
                                                    call: Call<List<HotelLookHotelResponse2>>,
                                                    t: Throwable
                                                ) {
                                                    Log.e(
                                                        "HotelError3",
                                                        "Ошибка при запросе: ${t.message}"
                                                    )
                                                }
                                            })

                                        }
                                    } else {
                                        Log.e(
                                            "HotelError4",
                                            "Ошибка при запросе: ${hotelResponse.code()}"
                                        )
                                    }
                                }

                                override fun onFailure(
                                    call: Call<HotelLookResponse>,
                                    t: Throwable
                                ) {
                                    Log.e("HotelLookError", "Ошибка при запросе: ${t.message}")
                                }
                            })
                    }
                    binding.hotelRec.layoutManager = LinearLayoutManager(this@MainActivity)
                    binding.hotelRec.adapter = adapter
                    binding.sVideo.visibility = View.GONE
                    binding.sVideo.startAnimation(fadeOut)
                    setupSearch()

                } else {
                    Log.e("Error", "Ошибка: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<Any>, t: Throwable) {
                Log.e("Error", "Ошибка при запросе: ${t.message}")
            }
        })
    }



    private fun recInit() {
        // Адаптер списка отелей
        binding.hotelRec.layoutManager = LinearLayoutManager(this@MainActivity)
        binding.hotelRec.adapter = adapter
    }

    @SuppressLint("SetTextI18n")
    private fun mainFuncAdapter() {
        binding.searchHotelsEditText.setOnClickListener {
            // Обработка нажатия на Edittext
            if (page != 2) {openSearch()}
        }

        binding.bottomNav.setOnItemSelectedListener {
            // Обработка нижнего меню
            when (it.itemId) {
                R.id.house -> {
                    if (page != 1) {openHome()}
                    true
                }

                R.id.search -> {
                    if (page != 2) {openSearch()}
                    true
                }

                R.id.site -> {
                    val url = "https://ostrovok.ru/"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }

        binding.close.setOnClickListener {
            // Закрытие экрана поиска
            openHome()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
            binding.bottomNav.selectedItemId = R.id.house
        }

        binding.clear.setOnClickListener {
            // Очистка текста
            if(binding.searchHotelsEditText.text.isNotEmpty()) {
                binding.searchHotelsEditText.setText("")
            }
        }
    }

    private fun initAnim() {
        // Анимации перехода
        fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        fadeOut = AnimationUtils.loadAnimation(this, R.anim.fade_out)
        fromY1toY0 = AnimationUtils.loadAnimation(this, R.anim.from_y1_to_y0)
        fromY0toY1 = AnimationUtils.loadAnimation(this, R.anim.from_y0_to_y1)
        toTop1 = AnimationUtils.loadAnimation(this, R.anim.to_top1)
        toBottom2 = AnimationUtils.loadAnimation(this, R.anim.to_bottom2)
        fromTopToCenterFadeIn = AnimationUtils.loadAnimation(this, R.anim.from_top_to_center_fade_in)
        toTopFadeOut = AnimationUtils.loadAnimation(this, R.anim.to_top_fade_out)
    }

    private fun openHome(){
        // Анимации перехода
        binding.bottomNav.visibility = View.VISIBLE
        binding.bottomNav.startAnimation(toTop1)
        binding.searchCity.startAnimation(fadeIn)
        binding.searchCity.visibility = View.VISIBLE
        binding.icon.startAnimation(fadeIn)
        binding.icon.visibility = View.VISIBLE
        page = 1
        binding.sVideo.visibility = View.GONE
        binding.filters.startAnimation(fadeIn)
        binding.filters.visibility = View.VISIBLE
        binding.searchCity.visibility = View.VISIBLE

        binding.hotelRec.visibility = View.VISIBLE
        originalHotelList.forEach { adapter.addHotel(it) }
        // Смещение Edittext при смене экрана
        val pixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 54f, resources.displayMetrics)
        binding.searchHotels.post {
            binding.searchHotels.translationY -= pixels
        }
        binding.searchHotels.animate()
            .translationY(0f) // Перемещаем вниз на 50dp
            .setDuration(200) // Длительность анимации в миллисекундах
            .withEndAction {
            }
            .start()

    }

    private fun openSearch() {
        binding.searchHotelsEditText.requestFocus()
        // Открытие клавиатуры
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(binding.searchHotelsEditText, InputMethodManager.SHOW_IMPLICIT)
        isCityMay = false

        // Анимации перехода
        binding.searchCity.visibility = View.GONE
        binding.searchCity.isClickable = false
        binding.search.visibility = View.VISIBLE
        binding.searchCity.startAnimation(fadeOut)
        binding.searchCity.visibility = View.GONE
        binding.bottomNav.startAnimation(toBottom2)
        binding.bottomNav.visibility = View.GONE
        binding.icon.startAnimation(fadeOut)
        binding.icon.visibility = View.GONE
        fadeOut.fillAfter = true
        fromY0toY1.fillAfter = true
        page = 2

        binding.hotelRec.visibility = View.GONE

        val pixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 54f, resources.displayMetrics)
        // Смещение Edittext при смене экрана
        binding.searchHotels.post {
            binding.searchHotels.translationY -= pixels
        }
        binding.searchHotels.animate()
            .translationY(-pixels) // Перемещаем вверх на 50dp
            .setDuration(200) // Длительность анимации в миллисекундах
            .withEndAction {
            }
            .start()

        binding.sVideo.visibility = View.VISIBLE
        binding.sVideo.startAnimation(fadeIn)
        binding.filters.startAnimation(fadeOut)
        toTopFadeOut.fillAfter = true
        binding.filters.visibility = View.GONE
    }
    @Deprecated("This method has been deprecated in favor of using the\n      {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n      The OnBackPressedDispatcher controls how back button events are dispatched\n      to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        // Обработка нажатия на кнопку назад
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
        if (page != 1) {
            openHome()
            binding.bottomNav.selectedItemId = R.id.house
        }
        else{super.onBackPressed()}
    }

    data class Guest(
        // DataClass гостей
        val adults: Int,
        val children: List<Any>
    )

    data class SearchRequest(
        // DataClass API
        val checkin: String,
        val checkout: String,
        val residency: String,
        val language: String,
        val guests: List<Guest>,
        val region_id: Int,
        val currency: String,
        val hotels_limit:Int
    )

    interface ApiService {
        // Авторизация API
        @POST("api/b2b/v3/search/serp/region/")
        fun searchHotels(
            @Header("Authorization") authHeader: String,
            @Body requestBody: SearchRequest
        ): Call<Any>
    }

    object RetrofitInstance {
        // API билд
        private const val BASE_URL = "https://api.worldota.net/"

        val api: ApiService by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }

    private fun sendReguest() {
        // Отправление запроса
        RetrofitInstance.api.searchHotels(credentials, requestData).enqueue(object : Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                if (response.isSuccessful) {
                    Log.d("ResponseOstrov", "Успешный ответ: ${response.body()}")
                } else {
                    Log.e("Error", "Ошибка: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<Any>, t: Throwable) {
                Log.e("Error", "Ошибка при запросе: ${t.message}")
            }
        })
    }

    private fun apiAuth(reg: Int) {
        // Входные данные API
        requestData = SearchRequest(
            checkin = "2024-11-10",
            checkout = "2024-11-11",
            residency = "ru",
            language = "ru",
            guests = listOf(Guest(2, listOf())),
            region_id = reg,
            currency = "RUB",
            hotels_limit = 20
        )

        // Базовая аутентификация
        credentials = Credentials.basic("10205", "abd18446-0971-4b0b-91f1-d8f256350b45")
    }

    fun formatHotelId(hotelId: String): String {
        // Изменение id отеля
        return hotelId.split("_").joinToString(" ") { it.capitalize(Locale.ROOT) }
    }
    interface HotelLookService {
        @GET("lookup.json")
        fun getHotelByName(
            @Query("query") hotelName: String,
            @Query("lang") lang: String = "ru",
            @Query("lookFor") lookFor: String = "both",
            @Query("limit") limit: Int = 20
        ): Call<HotelLookResponse>
    }
    data class HotelLookResponse(
        val status: String,
        val results: HotelLookResults
    )

    data class HotelLookResults(
        val hotels: List<HotelLookHotel>
    )

    data class HotelLookHotel(
        val id: String,
        val label: String,
        val price: Any
    )
    object HotelLookRetrofitInstance {
        private const val BASE_URL = "https://engine.hotellook.com/api/v2/"

        val api: HotelLookService by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(HotelLookService::class.java)
        }
    }
    interface HotelLookService2 {
        @GET("cache.json")
        fun getHotelByLocation(
            @Query("location") city: String,
            @Query("currency") currency: String,
            @Query("checkIn") checkIn: String,
            @Query("checkOut") checkOut: String,
            @Query("limit") limit: Int
        ): Call<List<HotelLookHotelResponse2>>
    }
    data class HotelLookHotelResponse2(
        val locationId: Int,
        val hotelId: Int,
        val priceFrom: Double,
        val stars: Int,
        val hotelName: String,
        val location: HotelLocation2
    )

    data class HotelLocation2(
        val name: String,
        val country: String,
        val geo: GeoCoordinates2
    )

    data class GeoCoordinates2(
        val lat: Double,
        val lon: Double
    )
    object HotelLookRetrofitInstance2 {
        private const val BASE_URL = "https://engine.hotellook.com/api/v2/"

        val api: HotelLookService2 by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(HotelLookService2::class.java)
        }
    }

    override fun onClick(hotelData: HotelData) {
        val id = hotelData.id
        val hotelName = hotelData.nameOfHotel
        val priceFrom1 = hotelData.priceFrom1
        val priceFrom2 = hotelData.priceFrom2
        val rate = hotelData.rate!!.toInt()

        val sharedPref = getSharedPreferences("hotel", Context.MODE_PRIVATE).edit()
        sharedPref.putString("id", id).apply()
        sharedPref.putString("hotelName", hotelName).apply()
        sharedPref.putInt("rate", rate).apply()

        startActivity(Intent(this@MainActivity, HotelView::class.java))
    }


}